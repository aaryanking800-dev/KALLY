# KALLY — Android AI Assistant (starter project)

A lightweight Kotlin + Jetpack Compose starter for a JARVIS-inspired Hinglish assistant.

## Included in this starter
- Welcome screen, Kelly loading screen, Step 1 permissions checklist, Step 2 special-access checklist, and futuristic home/chat screen.
- Runtime microphone/camera permission requests.
- System settings shortcuts for overlay, notification listener, accessibility, battery optimisation and default-assistant settings (where supported).
- Text-to-speech replies and speech recognition using Android APIs.
- Starter local memory using SharedPreferences.
- Quick actions for flashlight (where hardware/API permits), volume panel, camera, browser and alarms.
- Voice commands include a starter generic installed-app launcher for commands such as “open Calculator” or “Calculator kholo”, plus YouTube/WhatsApp shortcuts; media play/pause/next are best-effort and depend on the active app/media session.
- Explicit placeholders and setup notes for Gemini Live, WhatsApp workflows and paired-PC control.

## Build
1. Open this folder in Android Studio (recent stable version).
2. Let Gradle sync and install the Android SDK required by `compileSdk`.
3. Run on a physical Android device. The project uses package `com.kally.assistant`.
4. Voice recognition uses Android's installed speech recognition service and may require internet depending on the device.
5. For Gemini Live, create a Firebase project and configure Firebase AI Logic as documented by Google. Do not put private API keys in source control.

## Important limitations
- This is a starter source project, not a prebuilt or tested APK. Build and test on your phone before relying on it.
- “Hey KALLY” always-on wake-word detection is not implemented yet. Opening another app does not keep the current speech recognizer listening; a foreground-service wake-word engine is a separate required stage. Reliable offline wake word needs a dedicated on-device wake-word engine/model and a user-started foreground microphone service. Android versions and OEM battery management can stop background work.
- Android 12+ restricts background foreground-service starts; Android 14+ enforces microphone foreground-service prerequisites. A persistent notification and explicit user opt-in are required for a compliant always-listening mode.
- Android does not permit arbitrary silent control of every phone function. Special permissions/roles are granted in system Settings; this app only opens those settings pages.
- WhatsApp automation is limited to supported share/deep-link/notification workflows and must not bypass app security or send messages without user confirmation.
- PC control is not implemented: add a paired, authenticated local-network agent and require confirmation for sensitive actions.
- General question answering is not yet connected to an AI model, so this starter cannot promise accurate answers until Gemini/Firebase AI Logic is integrated. Gemini Live is an integration placeholder; configure Firebase AI Logic and follow the current official docs before enabling it.
- Accessibility service, notification access, overlay and default-assistant roles are powerful. Enable only if you understand the access and keep the user in control.
