package com.kally.assistant

import android.Manifest
import android.app.AlarmClock
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Bg = Color(0xFF030812)
private val Panel = Color(0xFF09182A)
private val Cyan = Color(0xFF26C6FF)
private val Muted = Color(0xFF9CB8CF)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { KallyApp() }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
    }
    fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kally_reply") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun KallyApp() {
    val context = LocalContext.current
    val activity = context as MainActivity
    var screen by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var reply by remember { mutableStateOf("Namaste! Main KALLY hoon. Aapki kya madad karun?") }
    val history = remember { mutableStateListOf("KALLY: Namaste! Main KALLY hoon.") }
    val prefs = remember { context.getSharedPreferences("kally_memory", Context.MODE_PRIVATE) }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) { input = spoken; val r = handleCommand(context, spoken, prefs); reply = r; history.add("You: $spoken"); history.add("KALLY: $r"); activity.speak(r) }
        listening = false
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF07182D), Bg, Color.Black)))) {
            when (screen) {
                0 -> WelcomeScreen { screen = 1 }
                1 -> LoadingScreen { screen = 2 }
                2 -> SetupOne(onNext = { permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)); screen = 3)
                3 -> SetupTwo(onFinish = { screen = 4 }, onSetting = { action -> openSetting(context, action) })
                else -> HomeScreen(
                    reply = reply, history = history, input = input, onInput = { input = it },
                    onMic = {
                        listening = true
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye, main sun rahi hoon")
                        }
                        try { speechLauncher.launch(intent) } catch (_: Exception) { listening = false; Toast.makeText(context, "Speech recognition available nahi hai", Toast.LENGTH_LONG).show() }
                    },
                    onSend = { command ->
                        if (command.isNotBlank()) {
                            history.add("You: $command")
                            val r = handleCommand(context, command, prefs)
                            reply = r; history.add("KALLY: $r"); activity.speak(r); input = ""
                        }
                    },
                    onTool = { tool -> reply = quickAction(context, tool); activity.speak(reply); history.add("KALLY: $reply") },
                    onSettings = { screen = 3 }
                )
            }
        }
    }
}

@Composable
private fun WelcomeScreen(onNext: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        CoreOrb()
        Spacer(Modifier.height(28.dp))
        Text("KALLY", fontSize = 42.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 7.sp)
        Text("YOUR PERSONAL AI", color = Cyan, letterSpacing = 3.sp)
        Spacer(Modifier.height(36.dp))
        Text("Smarter • Faster • Always with you", color = Muted)
        Spacer(Modifier.height(40.dp))
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) { Text("GET STARTED  →") }
    }
}
@Composable
private fun LoadingScreen(onNext: () -> Unit) {
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(1500); onNext() }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("💖", fontSize = 70.sp)
        Text("Kelly", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(12.dp)); Text("One moment.... Loading💕", color = Muted)
        Spacer(Modifier.height(22.dp)); CircularProgressIndicator(color = Cyan)
    }
}
@Composable
private fun SetupOne(onNext: () -> Unit) {
    val items = listOf("Microphone", "Camera", "Phone calls", "Connect / Contacts", "SMS", "Location", "Gallery & files", "Answer & manage calls")
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text("Set up KALLY", fontSize = 30.sp, color = Color.White, fontWeight = FontWeight.Bold)
        Text("Step 1 of 2", color = Cyan); Spacer(Modifier.height(18.dp))
        items.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                row.forEach { item -> Card(Modifier.weight(1f).padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.fillMaxWidth().padding(15.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(iconFor(item), null, tint = Cyan, modifier = Modifier.size(28.dp)); Spacer(Modifier.height(8.dp))
                        Text(item, color = Color.White, fontSize = 13.sp)
                    }
                } }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("CONTINUE") }
        Text("Permissions sirf zaroorat par maangi jayengi.", color = Muted, fontSize = 12.sp)
    }
}
@Composable
private fun SetupTwo(onFinish: () -> Unit, onSetting: (String) -> Unit) {
    val items = listOf("Battery — no optimisation" to "battery", "Display over other apps" to "overlay", "Notification access" to "notifications", "Accessibility service" to "accessibility", "Default assistant" to "assistant")
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text("Set up KALLY", fontSize = 30.sp, color = Color.White, fontWeight = FontWeight.Bold)
        Text("Step 2 of 2", color = Cyan); Spacer(Modifier.height(18.dp))
        items.forEach { (label, action) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel), onClick = { onSetting(action) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, null, tint = Cyan); Spacer(Modifier.width(14.dp))
                    Text(label, color = Color.White, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = onFinish, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("FINISH SETUP") }
        Text("Optional special access: aap baad mein Settings se badal sakte hain.", color = Muted, fontSize = 12.sp)
    }
}
@Composable
private fun HomeScreen(reply: String, history: List<String>, input: String, onInput: (String) -> Unit, onMic: () -> Unit, onSend: (String) -> Unit, onTool: (String) -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("◈ KALLY", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Cyan) }
        }
        Spacer(Modifier.height(14.dp)); Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { CoreOrb() }
        Text("I'M KALLY", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
        Text("Your AI Assistant • Hinglish", color = Cyan, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) { Text(reply, color = Color.White, modifier = Modifier.padding(14.dp)) }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) { items(history.takeLast(8)) { Text(it, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 3.dp)) } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(input, onInput, modifier = Modifier.weight(1f), placeholder = { Text("KALLY se baat karein…") }, singleLine = true)
            IconButton(onClick = onMic, modifier = Modifier.size(52.dp).background(Cyan.copy(alpha=.18f), CircleShape)) { Icon(Icons.Default.Mic, "Speak", tint = Cyan) }
            IconButton(onClick = { onSend(input) }, modifier = Modifier.size(52.dp).background(Cyan.copy(alpha=.18f), CircleShape)) { Icon(Icons.Default.Send, "Send", tint = Cyan) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            listOf("Apps", "Flashlight", "Volume", "Camera").forEach { label ->
                OutlinedButton(onClick = { onTool(label) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 3.dp)) { Text(label, fontSize = 10.sp) }
            }
        }
    }
}
@Composable
private fun CoreOrb() {
    Box(Modifier.size(180.dp).background(Brush.radialGradient(listOf(Color(0xFF0D76FF).copy(alpha=.5f), Color(0xFF06182D), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
        Box(Modifier.size(112.dp).background(Color(0xFF0B2A50), CircleShape), contentAlignment = Alignment.Center) {
            Box(Modifier.size(84.dp).background(Color(0xFF0B6EBB).copy(alpha=.35f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AutoAwesome, null, tint = Cyan, modifier = Modifier.size(48.dp))
            }
        }
    }
}
private fun iconFor(s: String) = when {
    s.contains("Micro") -> Icons.Default.Mic
    s.contains("Camera") -> Icons.Default.CameraAlt
    s.contains("Phone") || s.contains("calls") -> Icons.Default.Call
    s.contains("SMS") -> Icons.Default.Message
    s.contains("Location") -> Icons.Default.LocationOn
    s.contains("Gallery") -> Icons.Default.Photo
    else -> Icons.Default.Link
}
private fun openSetting(context: Context, action: String) {
    val intent = when(action) {
        "battery" -> Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).setData(Uri.parse("package:${context.packageName}"))
        "overlay" -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).setData(Uri.parse("package:${context.packageName}"))
        "notifications" -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        "assistant" -> Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)
        else -> Intent(Settings.ACTION_SETTINGS)
    }
    try { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
private fun handleCommand(context: Context, raw: String, prefs: android.content.SharedPreferences): String {
    val c = raw.lowercase(Locale.ROOT)
    return when {
        c.contains("flashlight") || c.contains("torch") || c.contains("टॉर्च") -> quickAction(context, "Flashlight")
        c.contains("volume") || c.contains("आवाज़") || c.contains("वॉल्यूम") -> quickAction(context, "Volume")
        c.contains("camera") || c.contains("कैमरा") -> quickAction(context, "Camera")
        c.contains("youtube") -> { openUrl(context, "https://m.youtube.com"); "YouTube khol raha hoon." }
        c.contains("browser") || c.contains("google") || c.contains("search") -> { openUrl(context, "https://www.google.com"); "Browser khol raha hoon." }
        c.contains("whatsapp") -> { openUrl(context, "https://wa.me/"); "WhatsApp khol raha hoon. Message bhejne se pehle aap confirm karein." }
        c.startsWith("remember ") || c.startsWith("yaad rakho ") -> {
            val value = raw.substringAfter(' ').trim()
            prefs.edit().putString("memory_${System.currentTimeMillis()}", value).apply()
            "Theek hai, maine is baat ko is device par local memory mein save kar diya."
        }
        c.contains("alarm") || c.contains("अलार्म") -> {
            val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_MESSAGE, "KALLY reminder")
            try { context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Alarm set karne ki screen khol di hai." } catch (_: Exception) { "Alarm app available nahi hai." }
        }
        c.contains("open settings") || c.contains("settings kholo") -> { context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Settings khol raha hoon." }
        c.contains("hello") || c.contains("hi") || c.contains("namaste") || c.contains("kaise ho") || c.contains("कैसे हो") -> "Main theek hoon! Aapki kya madad karun?"
        else -> "Is starter version mein general knowledge ke sahi jawab ke liye AI model abhi connect nahi hai. Gemini AI integration add karne ke baad main aapke sawalon ka jawab de sakungi. Agar aap app kholna chahte hain to 'Open' ya 'Kholo' ke baad app ka naam boliye."
    }
}
private fun quickAction(context: Context, tool: String): String {
    return when(tool) {
        "Flashlight" -> {
            try {
                val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
                val id = cameraManager.cameraIdList.firstOrNull { cameraManager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                if (id != null) { cameraManager.setTorchMode(id, true); "Flashlight on kar di. Band karne ke liye command support next stage mein add hoga." } else "Is phone par flash nahi mila."
            } catch (_: Exception) { "Flashlight control nahi ho paya; camera permission/device support check karein." }
        }
        "Volume" -> { val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager; am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI); "Volume panel khol diya." }
        "Camera" -> { try { context.startActivity(Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Camera khol raha hoon." } catch (_: Exception) { "Camera app nahi mili." } }
        "Apps" -> { try { context.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Home screen khol di. Specific app opening next stage mein add hoga." } catch (_: Exception) { "Apps open nahi ho paye." }
        else -> "Ready."
    }
}
private fun openUrl(context: Context, url: String) {
    try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { Toast.makeText(context, "Browser nahi mila", Toast.LENGTH_SHORT).show() }
}
